from pathlib import Path
import hashlib,json,os,shlex,subprocess,shutil
lab=Path(__file__).resolve().parent;r=lab.parents[1];build=r/'tp-cache-retention/upstream-batched-hc-q8-build';src=r/'tp-cache-retention/upstream-batched-hc-q8-worktree'
assert json.loads((lab/'operator-test-result.json').read_text())['exit']==0
assert not(lab/'tp1-build-commands.json').exists()
env=os.environ.copy();env.update(json.loads((lab/'configure-v3.json').read_text())['environment'])
entries=json.loads((build/'compile_commands.json').read_text())
def compile(suffix,source,dest):
 e=next(x for x in entries if x['file'].endswith(suffix));cmd=shlex.split(e['command']);cmd[cmd.index('-o')+1]=str(lab/dest);cmd[-1]=str(lab/source);return cmd
batch=compile('/kernels/rocm/batch.cpp','tp1-diagnostic-batch.cpp','tp1-batch.o');main=compile('/hc_mix_ops_test.cpp','tp1-probe.cpp','tp1-probe.o')
main.insert(1,'-I'+str(r/'dependencies/gufo-dev/usr/include'))
assert '-DENGINE_ENABLE_HIP=1'in main and '-UNDEBUG'in main
assert not any('TP2_RDMA'in x for x in main+batch)
archive=build/'extensions/build/qwen38_flash_next/build/libgufo_qwen38_flash_next_hip.a';copy=lab/'tp1-diagnostic-hip.a';assert not copy.exists();shutil.copy2(archive,copy)
link=shlex.split(subprocess.check_output(['ninja','-C',str(build),'-t','commands','qwen38_flash_next_hc_mix_ops_test'],text=True).splitlines()[-1]);assert link[:2]==[':','&&']and link[-2:]==['&&',':'];link=link[2:-2]
i=next(i for i,x in enumerate(link)if x.endswith('/hc_mix_ops_test.cpp.o'));link[i]=str(lab/'tp1-probe.o');link=[str(copy)if x==str(archive.relative_to(build)) else x for x in link];link[link.index('-o')+1]=str(lab/'tp1-probe')
# ar replacement uses the production member's basename, not the test object's.
member=lab/'batch.cpp.o';commands=[batch,['cp',str(lab/'tp1-batch.o'),str(member)],['ar','r',str(copy),str(member)],main,link]
(lab/'tp1-build-commands.json').write_text(json.dumps(dict(commands=commands,cwd=str(build),environment=json.loads((lab/'configure-v3.json').read_text())['environment'],scope='Current canonical CMake GPU-test objects, no RDMA/private fork ABI. One batch member toggle/counters plus external test main. Correctness only, not production timing.'),indent=2)+'\n')
with(lab/'tp1-build.log').open('w')as f:
 for cmd in commands:subprocess.run(cmd,cwd=build,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
changes=[]
for m in subprocess.check_output(['ar','t',str(archive)],text=True).splitlines():
 if subprocess.check_output(['ar','p',str(archive),m])!=subprocess.check_output(['ar','p',str(copy),m]):changes.append(m)
assert changes==['batch.cpp.o'],changes
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(lab/'tp1-build-result.json').write_text(json.dumps(dict(changed_members=changes,binary_sha256=sha(lab/'tp1-probe'),source_commit=subprocess.check_output(['git','-C',str(src),'rev-parse','HEAD'],text=True).strip(),source_sha256={n:sha(lab/n)for n in('tp1-probe.cpp','tp1-diagnostic-batch.cpp')}),indent=2)+'\n')
print('Current-canonical TP1 numerical probe built; not yet executed.')

# Focused canonical-upstream batched HC Q8 port

Base: gufo-org/gufo `773a16419282a3b9790d685ce6b4dd980b285943`.
Local source branch: `perf/upstream-batched-hc-ready-q8`, commit `188c03c5`.
Only the 10-line reuse change and 48-condition operator contract test are ported.
No RDMA implementation or fork-private ABI is used. The maintained fork is unchanged.

## Completed evidence

- Shared format check: 866 C++ files pass (`format.log`). An initial command used
  the obsolete tools/check_format.py path and exited 2 before any check; the
  correct repository command is tools/ci/check-format.py.
- Independently configured/built current canonical HIP library and operator target.
  Current source headers, compiler/flags and library closure only.
- CTest HC operator suite passes on gfx1151, including all 48 new ready-Q8 cases.
  Real device execution and normal suite output are in the build's
  Testing/Temporary/LastTest.log; no missing-device skip route exists in this test.
- Initial configure failed due unrooted local pkg-config paths; configure-v2 used
  the dependency sysroot but stale package-discovery state omitted WebP at link.
  Original cache/logs retained. configure-v3 regenerated from a clean CMake cache
  with the correct dependency root; no source or system workaround was applied.

## Single-node full-model qualification

`tp1-design.json` describes the fixed scope; `build-tp1.py` builds only an isolated
batch-object producer toggle/counters and external main against this canonical
build. The original production CMake archive is retained unchanged. The diagnostic
archive differs in exactly batch.cpp.o. This is a correctness artifact, not a
production timing binary or an independent model teacher.

`run-tp1.py` takes the existing model-matrix lock, records boot/cmdline and binary
identity, then exercises four independent 65,536-capacity sessions at short and
actual 32,768-token contexts, greedy and sampled RNG, complete finite logits,
borrowed same/cross-session restores, serialized and file restores, and complete
materialized post-replay state. All 104 records, 44 enabled cycles and 32 complete
state pairs are required; failure records remain. No performance conclusion is
inferred from the test. Memory guard aborts below 8 GiB available.

Canonical DecodeRequest lacks the fork's per-request proposal ceiling and TP plan
parameter. The probe uses canonical production proposal policy (maximum seven),
records actual packed verification widths and checks eligible Q8 production or
wide fallback. It does not claim the prescribed two/three-row fork test shapes.
A possible controller/work divergence must be reported as a failed comparison,
not hidden by changing the production policy or loosening numerical equality.

Upstream publication and any further coverage depend on this result. Fork PR14
still has inconclusive end-to-end throughput evidence; no gain/adoption claim.
